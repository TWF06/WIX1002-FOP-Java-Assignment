package viva2final;
import java.util.Scanner;

public class Q6 {

     
    public static boolean canbePalindrome(String str)
    {
        str = str.toLowerCase();
        int[] charC = new int[26];
    
        for (int i = 0; i < str.length(); i++) 
        {
            char c = str.charAt(i);
            
            if (c >= 'a' && c <= 'z') 
            {
                int index = c - 'a';
                charC[index]++;
            }
        }
        
        int oddC = 0;

        for (int i = 0; i < 26; i++) 
        {
            if (charC[i] % 2 != 0) 
            {
                oddC++;
            }
        }
        return oddC <= 1;
    }
    
    public static String reverseString(String str) 
    {
        String revS= "";
        
        for (int i = str.length() - 1; i >= 0; i--) 
        {
            revS = revS + str.charAt(i); 
        }
        return revS;
    }
    

    //charC Array holding half the counts needed for the permutation.
    //currentHalf The currently built first half of the palindrome.
    //It will keep on building until the currentlyHalf is same as the half passed from getPossiblePalindrome.
    public static void generatePermutations(int[] charC, String currentHalf, int half, String center) 
    {

        if (currentHalf.length() == half) 
        {

            String revHalf = reverseString(currentHalf);
            System.out.println(currentHalf + center + revHalf);
            return;
        }

        for (int i = 0; i < 26; i++) 
        {
            if (charC[i] > 0) 
            {
 
                char ch = (char)('a' + i);
                charC[i]--; 
                generatePermutations(charC, currentHalf + ch, half, center);
                charC[i]++; 
            }
        }
    }
    
    //Store how many counts of the alphabets in an array. 
    //Then, find out the center, call generatePermutation method to find possible Palindromes.
    public static void getPossiblePalindrome(String str)
    {
        str = str.toLowerCase();
        int[] charC = new int[26];

        for (int i = 0; i < str.length(); i++) 
        {
            char c = str.charAt(i);
            if (c >= 'a' && c <= 'z') 
            {
                charC[c - 'a']++;
            }
        }
        
        String center = "";
        int leftHalfLength = 0;

        for (int i = 0; i < 26; i++) 
        {
            int count = charC[i];
            
            if (count % 2 != 0) {
                center = String.valueOf((char)('a' + i));
            }

            charC[i] = count / 2;
            leftHalfLength += charC[i];
        }

        System.out.println("All possible palindrome:");

        generatePermutations(charC, "", leftHalfLength, center);
    
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String str;
        do
        {
            Boolean allLetters = true;
            System.out.print("Enter string: ");
            str = s.nextLine();
            for(int i = 0; i<str.length(); i++)
            {
                char c = str.charAt(i);
                if(!Character.isLetter(c)) 
                {
                   allLetters = false;
                   break;
                }
            }  

            if(allLetters)
            {
                break;
            }
            else
            {
                System.out.println("Invalid input. No numbers and symbols.");
            }  
        }
        while(true);
        
        System.out.println("Can be palindrome? ");
        if (canbePalindrome(str)) 
        {
            
            getPossiblePalindrome(str); 
            
        } else {
            System.out.println("Cannot be palindrome.");
        }
 
    }
    
}