package viva2final;

//message encoder
import java.util.Random;
import java.util.Scanner;

public class Q2 {

    // Insert one special character after one character of string. 
    public static String insert(String str)
    {
        String speC = "@#$";
        Random r = new Random();
        String result = ""; 

        for (int i = 0; i < str.length(); i++) 
        {
            
            char strC = str.charAt(i);
            int indexSpeC = r.nextInt(3); 
            char randSpeC = speC.charAt(indexSpeC);

            result = result + strC + randSpeC;
        }
        return result;        
    }
    
    //break the string into 2 and reversed both of them
    public static String breakAndFlip(String str)
    {
        int length = str.length();
        int mid = length/2;
        String revS ="";
        String left = str.substring(0,mid);
        String revL ="";
        String revR ="";
        String right = str.substring(mid, length);
        for(int i= left.length()-1; i>=0; i--)
        {
            revL = revL + left.charAt(i);
        }
        for(int i= right.length()-1; i>=0; i--)
        {
            revR = revR + right.charAt(i);
        }
        revS = revS + revL + revR;
        return revS;
    }
    
    // shift each character of string excluding the special characters
    public static String shift(String str)
    {
        int length = str.length();
        String shiftS = "";
        char shiftC = ' ';
        for(int i = 0; i< length;i++ )
        {
            char c = str.charAt(i);
            if (Character.isDigit(c)) 
            { 
                shiftC = (char)(c + 10 + i);
        
            } 
            else if(Character.isUpperCase(c)) 
            {  
                shiftC = (char)(c + 2 + i);
            
            } 
            else if(Character.isLowerCase(c)) 
            { 
                shiftC = (char)(c + 3 + i);
            }
            else
            {
                shiftC = c;
            }
            shiftS = shiftS + shiftC;
        }
        return shiftS;
    }
    
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter message: ");
        String str = s.nextLine();
        String iS = insert(str);
        String bAF = breakAndFlip(iS);
        String sh = shift(bAF);
        System.out.println("Step 1 (Insert): "+ iS);
        System.out.println("Step 2 (Break and Flip): "+ bAF);
        System.out.println("Step 3 (Shift): "+ sh);
    }
    
}
