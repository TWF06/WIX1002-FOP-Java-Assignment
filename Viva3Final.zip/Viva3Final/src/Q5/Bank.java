package Q5;

import java.util.ArrayList;

public class Bank 
{
    String bankName;
    ArrayList<Customer> customers;
    
    public Bank(String bankName)
    {
       this.bankName = bankName; 
       customers = new ArrayList<Customer>();
       System.out.println("Welcome to "+ bankName + "! ");
       
       
    }
    
    public void addCustomer(Customer customer)
    {
        customers.add(customer);
        System.out.println("Creating a new customer: " + customer.getName() + " (ID: " + customer.getCustomerId() + ")\n");
        
    }
    
    public Customer getCustomer(String customerId)
    {
        for(int i = 0; i< customers.size();i++)
        {
            Customer cus = customers.get(i);
            if(cus.getCustomerId().equals(customerId))
            {
                return cus;        
            }       
        }
        return null;
    }
    
    public void displayAllCustomers()
    {
        System.out.println("\nDisplaying all customers of " + bankName + ":");
        for(int i = 0; i < customers.size(); i++)
        {
            Customer cus = customers.get(i);
            System.out.println("Customer: " + cus.getName() + ", ID: " + cus.getCustomerId());
        }
    }
}



