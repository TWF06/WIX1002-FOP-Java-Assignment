package Q5;

public class BankAccount 
{
    private String accountNumber;
    private String accountHolderName;
    private double balance = 0.0;
    
    public BankAccount(String accountNumber, String accountHolderName, double iniDeposit)
    {
       this.accountNumber = accountNumber; 
       this.accountHolderName = accountHolderName;
       setBalance(iniDeposit);
    }
    
    public void deposit(double amount)
    {
        setBalance(this.balance + amount);
        System.out.println("Depositing $" + amount + " into account " + accountNumber + "..."); 
        System.out.println("New balance: $" + balance+ "\n"); 
    }
    
    public boolean withdraw(double amount)
    {
        System.out.println("Withdrawing $" + amount + " from account " + accountNumber + "...");
        if(balance>=amount)
        {
            setBalance(this.balance - amount);
            System.out.println("New balance: $" + balance + "\n");
            return true;
        }
        else
        {
            System.out.println("You do not have sufficient amount to withdraw.\n");
            return false;
        }
    }
    
    public String getAccountNumber() 
    { 
        return accountNumber; 
    }
    
    public String getAccountHolderName() 
    { 
        return accountHolderName; 
    }
    
    public double getBalance() 
    { 
        return balance; 
    }
    
    private void setBalance(double balance) 
    {
        this.balance = balance;
    }
}




