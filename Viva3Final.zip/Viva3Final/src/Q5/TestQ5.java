
package Q5;

public class TestQ5 {

    public static void main(String[] args) 
    {
       Bank sB = new Bank("SimpleBank");
       Customer john = new Customer("John Doe", "C001");
       sB.addCustomer(john);
       
       BankAccount j1 = new BankAccount("A1001", "John Doe", 500.0);
       john.addAccount(j1);
       
       j1.deposit(200.0);
       j1.withdraw(100.0);
       
       john.displayAccounts();
       sB.displayAllCustomers();
                
        /*Bank bankH= new Bank("Hard Bank");
        
        Customer samuelC = new Customer("Samuel", "C001");
        Customer calvinC = new Customer("Calvin", "C002");
        bankH.addCustomer(samuelC);
        bankH.addCustomer(calvinC);
        
        BankAccount samuelBA1 = new BankAccount("A1001","Samuel",500);
        BankAccount samuelBA2 = new BankAccount("A1002","Samuel",5000);
        BankAccount calvinBA1 = new BankAccount("A1003","Calvin",1000);
        samuelC.addAccount(samuelBA1);
        samuelC.addAccount(samuelBA2);
        calvinC.addAccount(calvinBA1);
        
        samuelBA1.deposit(200);
        
        samuelBA2.deposit(600);
        
        calvinBA1.deposit(200);
        samuelBA1.withdraw(100);
        
        samuelBA2.withdraw(500);
        
        calvinBA1.withdraw(100);
        
        samuelC.displayAccounts();
        calvinC.displayAccounts();
        bankH.displayAllCustomers();*/
    
    }   
}
