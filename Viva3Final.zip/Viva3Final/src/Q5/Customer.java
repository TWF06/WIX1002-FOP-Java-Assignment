package Q5;

import java.util.ArrayList;

public class Customer 
{
    String name;
    String customerId;
    ArrayList<BankAccount> accounts;
    
    public Customer(String name, String customerId)
    {
        this.name = name;
        this.customerId = customerId;
        this.accounts = new ArrayList<>();
    }
    
    public void addAccount(BankAccount account)
    {
        accounts.add(account);
        System.out.println("Adding a savings account for " + name + " with account number " + account.getAccountNumber()+" and an initial deposit of $" + account.getBalance()+ "\n");
    }
    
    public BankAccount getAccount(String accountNumber) 
    {
        for (int i = 0; i < accounts.size(); i++) 
        {       
            BankAccount acc = accounts.get(i); 
        
            if (acc.getAccountNumber().equals(accountNumber)) 
            {
                return acc; 
            }
        }
        
        return null;
    }
    
    public void displayAccounts()
    {
        System.out.println("\nDisplaying all accounts for customer " + name + ":");
        for(int i = 0; i< accounts.size(); i++)
        {
            BankAccount acc = accounts.get(i);
            System.out.println("Account Number: " + acc.getAccountNumber() + ", Balance: $" + acc.getBalance()); 
        }
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getCustomerId()
    {
        return customerId;
    }
    
                 
           
}






