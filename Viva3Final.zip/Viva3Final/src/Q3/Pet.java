package Q3;

// represent a pet in adoption centre
// store pet's details and adoption information
public class Pet {
        
    private String name;
    private String species;
    private String breed;
    private int age;
    private String healthRecord;
    private boolean isAdopted;
    private String adopterName;
    
    // constructor to initialize pet details
    public Pet (String name, String species, String breed, int age, String healthRecord) {
        this.name = name;
        this.species = species;
        this.breed = breed;
        this.age = age;
        this.healthRecord = healthRecord;
    }
    
    // marks the pet as adopted and store adopter's name
    public void adopt (String adopterName) {
        this.isAdopted = true;
        this.adopterName = adopterName;
    }
    
    // display full details of pet
    public void getDetails() {
        System.out.println("PetName: " + name);
        System.out.println("Species: " + species);
        System.out.println("Breed: " + breed);
        System.out.println("Age: " + age);
        System.out.println("HealthRecord: " + healthRecord);
        if (!isAdopted) {
            System.out.println("Adopted: not adopted");
        } else {
            System.out.println("Adopted: adopted");
        }
        System.out.println("AdopterName: " + adopterName);
    }
    
    // return pet's name
    public String getName() {
        return name;
    }
    
    // return pet's species
    public String getSpecies() {
        return species;
    }
    
    // return pet's age
    public int getAge() {
        return age;
    }
    
    // return adoption status
    public boolean isAdopted() {
        return isAdopted;
    }
}
