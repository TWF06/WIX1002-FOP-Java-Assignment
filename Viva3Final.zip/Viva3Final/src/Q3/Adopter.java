
package Q3;

// represent a person who wants to adopt pet
// store adopter preferences and match pet based on criteria
public class Adopter {
        
    private String name;
    private String preferredSpecies;
    private String preferredAgeRange;
    
    // constructor to initialize adopter information
    public Adopter (String name, String preferredSpecies, String preferredAgeRange) {
        this.name = name;
        this.preferredSpecies = preferredSpecies;
        this.preferredAgeRange = preferredAgeRange;
    }
    
    // displays pets that match adopter's preferences
    public void viewMatchingPets (PetAdoptionCentre centre) {
        String[] ageParts = preferredAgeRange.split("-");
        int minAge = Integer.parseInt(ageParts[0]);
        int maxAge = Integer.parseInt(ageParts[1]);
        
        for (Pet pet : centre.getPets()) {
            if (!pet.isAdopted() && pet.getSpecies().equalsIgnoreCase(preferredSpecies) && pet.getAge() >= minAge && pet.getAge() <= maxAge) {
                pet.getDetails();
                System.out.println();
            }
        }
    }
    
    // return adopter's name
    public String getName() {
        return name;
    }
}