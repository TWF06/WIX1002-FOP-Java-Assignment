package Q3;

import java.util.ArrayList;
import java.util.List;

// manage all pet and adoption processes
public class PetAdoptionCentre {
       
    private ArrayList<Pet> pets; // store all pets
    
    // constructor to initialize the pet list
    public PetAdoptionCentre() {
        pets = new ArrayList<>(); // initialize the list
    }
    
    // add new pet to adoption centre
    public void addPet(Pet pet) {
        pets.add(pet); 
    }
    
    // handle pet adoption process
    public void adoptPet (Pet pet, Adopter adopter) {
        if (pet != null && !pet.isAdopted()) {
            pet.adopt(adopter.getName());
        } else {
            System.out.println("Pet not available for adoption.");
        }
    }
    
    // display all available pet sorted by age
    public void viewAvailablePets() {
        // sort pets by age in ascending order
        pets.sort((p1, p2) -> Integer.compare(p1.getAge(), p2.getAge()));
        
        for (Pet pet: pets) {
            if (!pet.isAdopted()) {
                pet.getDetails();
                System.out.println();
            }
        }
    }
    
    // return pet based on name
    public Pet getPetByName (String petName) {
        for (Pet pet : pets) {
            if (pet.getName().equalsIgnoreCase(petName)) {
                return pet;
            }
        }
        return null;
    }
    
    // return list of all petsno 
    public List<Pet> getPets() {
        return pets;
    }
}
