package Q2;

public class Zoo 
{
    //a place to store our creatures inside
    private Creature[] c;
    private int count;
    
    public Zoo(int size) 
    {
        c = new Creature[size];
        count = 0;
    }
    
    public void addCreature(String species, double magicPower, String habitat)
    {
        if (count < c.length) 
        {
            c[count] = new Creature(species, magicPower, habitat);
            System.out.println(species + " added to the zoo."); 
            count++;
        } 
        else 
        {
            System.out.println("Zoo is full! Cannot add more creatures.\n");
        }
    }
    
    public void feedCreature(String species, double add)
    {
        for (int i = 0; i < count; i++)
        {
            if (c[i].species.equalsIgnoreCase(species)) 
            {
                c[i].feed(add);
                System.out.println(species + "'s magic power increased to " + c[i].magicPower + ".\n"); 
            }
        }
        
    }
    
    public void displayAllCreatures()
    {
        for(int i= 0; i< count; i++)
        {
            c[i].displayInfo();
        }
    }
}
