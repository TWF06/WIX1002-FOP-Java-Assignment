package Q2;

public class Creature 
{
    String species;
    double magicPower;
    String habitat;
    
    public Creature(String species,double magicPower, String habitat)
    {
        this.species = species;
        this.magicPower = magicPower;
        this.habitat = habitat;
    }
            
    public double feed(double foodAmount)
    {
        magicPower += foodAmount;
        return magicPower;
    }
    
    public void displayInfo()
    {
        System.out.println("Species: " + species);
        System.out.println("Magic Power: " + magicPower);
        System.out.println("Habitat: " + habitat + "\n");
    }
}
