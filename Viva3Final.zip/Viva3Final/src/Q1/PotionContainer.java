
package Q1;

// manage different potion ingredients
// allow adding, using, checking and displaying potion volume
public class PotionContainer {
    
    // Potion object to store specific ingredient
    private Potion unicornTears;
    private Potion dragonBlood;
    
    // add potion ingredient to the container
    public void addPotion (String ingredient, double volume) {
        if (ingredient.equalsIgnoreCase("Unicorn Tears")) {
            unicornTears = new Potion(ingredient, volume);
        } else if (ingredient.equalsIgnoreCase("Dragon Blood")) {
            dragonBlood = new Potion(ingredient, volume);
        }
        System.out.println(volume + " ml of " + ingredient + " added to the container.");
    }
    
    // use specified amount of potion ingredient
    public void usePotion (String ingredient, double volume) {
        Potion p = getPotion(ingredient);
        
        // if potion does not exist, stop the method
        if (p == null) {
            System.out.println("Potion not found.");
            return;
        }
        
        if (p.use(volume)) {
            System.out.println(volume + " ml of " + ingredient + " used.");
        } else {
            System.out.println("Not enough " + ingredient + " available.");
        }
    }
    
    // return remaining volume of potion ingredient
    public double getRemainingVolume (String ingredient) {
        Potion p = getPotion(ingredient);
        
        if (p != null) {
            return p.getVolume();
        } else {
            return 0;
        }
    }
    
    // check if there are enough ingredients to brew the invisibility draught
    public boolean isEnoughForPotion (double requiredUnicornTears, double requiredDragonBlood) {
        if (unicornTears == null || dragonBlood == null) {
            return false;
        }
        return unicornTears.getVolume() >= requiredUnicornTears && dragonBlood.getVolume() >= requiredDragonBlood;
    }
    
    // print final state of all potions in container
    public void printPotions() {
        System.out.println();
        System.out.println("--- Potion Inventory ---");
        System.out.printf("Unicorn Tears: %.2f ml\n", unicornTears.getVolume());
        System.out.printf("Dragon Blood: %.2f ml\n", dragonBlood.getVolume());
    }
    
    // to reduce repeated code
    // return potion object based on ingredient name
    private Potion getPotion (String ingredient) {
        if (ingredient.equalsIgnoreCase("Unicorn Tears")) {
            return unicornTears;
        } else if (ingredient.equalsIgnoreCase("Dragon Blood")) {
            return dragonBlood;
        }
        return null;
    }
}