
package Q1;

// represents single potion ingredient
// stores ingredient name and the remaining volume
public class Potion {
    
    private String ingredient; // name of ingredient
    private double volume; // current remaining value
    
    // constructor to initialize the ingredient and volume
    public Potion (String ingredient, double volume) {
        this.ingredient = ingredient;
        this.volume = volume;
    }
       
    // returns name of ingredient
    public String getIngredient() {
        return ingredient;
    }  
        
    // return remaining volume of potion
    public double getVolume() {
        return volume;
    }
    
    // use certain amount of potion
    // return true if usage is successful, false if not enough volume
    public boolean use (double amount) {
        if (amount > volume) {
            return false;
        } else {
            volume -= amount;
            return true;
        }
    }
}